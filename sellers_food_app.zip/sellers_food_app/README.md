# Sellers APP (restaurants app)



![alt text](https://github.com/taydinadnan/BringApp-Delivery-service-app/blob/main/sellers_food_app/ss/adnan%20SELLERS.jpg?raw=true)
