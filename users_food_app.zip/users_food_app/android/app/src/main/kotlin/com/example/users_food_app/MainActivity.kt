package com.example.users_food_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
