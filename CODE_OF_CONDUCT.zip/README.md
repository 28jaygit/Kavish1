

# Users APP



![alt text](https://github.com/taydinadnan/BringApp-Delivery-service-app/blob/main/users_food_app/ss/adnan%20APP.jpg?raw=true)


# Sellers APP (restaurants app)



![alt text](https://github.com/taydinadnan/BringApp-Delivery-service-app/blob/main/sellers_food_app/ss/adnan%20SELLERS.jpg?raw=true)


# Riders APP



![alt text](https://github.com/taydinadnan/BringApp-Delivery-service-app/blob/main/sellers_food_app/ss/adnan%20riders.jpg?raw=true)




# Admin Web Portal



![alt text](https://github.com/taydinadnan/BringApp-Delivery-service-app/blob/main/bringapp_admin_web_portal/ss/adnan%20admin%20web%20panel.jpg?raw=true)
